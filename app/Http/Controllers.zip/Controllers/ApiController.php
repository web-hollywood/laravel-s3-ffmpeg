<?php

namespace App\Http\Controllers;

class ApiController extends Controller
{

}
